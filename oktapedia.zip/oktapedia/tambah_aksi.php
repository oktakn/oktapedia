<?php
    include 'koneksi1.php';

    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $fakultas = $_POST['fakultas'];
    $jurusan = $_POST['jurusan'];
    $angkatan = $_POST['angkatan'];
   $tanggal = date("Y-m-d H:i:s");
  
    $sql = "INSERT INTO post VALUES('','$nama','$nim','$fakultas','$jurusan','$angkatan','$tanggal')";
mysqli_query($db,$sql);//perintah untuk insert data

    header("location:home.php");//akan kembali ke home setelah proses update
?>