<?php
    include 'koneksi1.php';//memanggil /terhubung ke database

    $id = $_POST['id_post'];
	$nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $fakultas = $_POST['fakultas'];
    $jurusan = $_POST['jurusan'];
    $angkatan = $_POST['angkatan'];
   $tanggal = date("Y-m-d H:i:s");
  

    mysqli_query($db,"update post set nama='$nama',nim='$nim',fakultas='$fakultas',jurusan='$jurusan',angkatan='$angkatan',tanggal='$tanggal' where id_post='$id'");//untuk mengupdate data

    header("location:home.php");//akan kembali ke home setelah proses update
?>