<?php
   $hostname  = "localhost";
   $username  = "root";
   $password  = "";
   $dbname  = "oktadb";
   $db = new mysqli($hostname, $username, $password, $dbname);
?>